﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CsevegesGUI
{
    class Beszelgetes
    {
        public DateTime Kezdete { get; private set; }
        public DateTime Vege { get; private set; }
        public string Kezdemenyezo { get; private set; }
        public string Fogado { get; private set; }

        public TimeSpan ElteltIdo => Vege - Kezdete;

        public Beszelgetes(string sor)
        {
            string[] m = sor.Split(';');
            Kezdete = DateTime.ParseExact(m[0], "yy.MM.dd-HH:mm:ss", CultureInfo.InvariantCulture);
            Vege = DateTime.ParseExact(m[1], "yy.MM.dd-HH:mm:ss", CultureInfo.InvariantCulture);
            Kezdemenyezo = m[2];
            Fogado = m[3];
        }
    }
    public partial class MainWindow : Window
    {
        List<Beszelgetes> beszelgetesek = new List<Beszelgetes>();

        private void ListakatFeltolt()
        {
            foreach (var b in beszelgetesek.OrderBy(x => x.Kezdemenyezo))
            {
                if (!cbKezdemenyezo.Items.Contains(b.Kezdemenyezo))
                {
                    cbKezdemenyezo.Items.Add(b.Kezdemenyezo);
                }
            }
            foreach (var b in beszelgetesek.OrderBy(x => x.Fogado))
            {
                if (!cbFogado.Items.Contains(b.Fogado))
                {
                    cbFogado.Items.Add(b.Fogado);
                }
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            foreach (var sor in File.ReadAllLines("csevegesek.txt").Skip(1))
            {
                beszelgetesek.Add(new Beszelgetes(sor));
            }
            ListakatFeltolt();
            cbKezdemenyezo.SelectedIndex = 0;
            cbFogado.SelectedIndex = cbFogado.Items.Count - 1;
        }

        private void SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lbCsevegesek.Items.Clear();
            string kezdemenyezo = (string)cbKezdemenyezo.SelectedItem;
            string fogado = (string)cbFogado.SelectedItem;
            int sorszam = 1;
            foreach (var b  in beszelgetesek)
            {
                if (b.Kezdemenyezo == kezdemenyezo && b.Fogado == fogado)
                {
                    lbCsevegesek.Items.Add($"{sorszam++}. {b.Kezdete.ToString("yy.MM.dd-HH:mm:ss")} --> {b.Vege.ToString("yy.MM.dd-HH:mm:ss")}");
                }
            }
            if (lbCsevegesek.Items.Count == 0) lbCsevegesek.Items.Add("Nem történt beszélgetés.");
        }
    }
}
