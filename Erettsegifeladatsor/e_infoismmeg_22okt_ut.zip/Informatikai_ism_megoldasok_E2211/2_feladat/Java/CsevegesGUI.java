import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Konzolos feladat során készült megoldásból átemelve
class Beszelgetes {
    private LocalDateTime kezdet;
    private LocalDateTime veg;
    private String kezdemenyezo;
    private String fogado;

    public LocalDateTime getKezdet() {
        return kezdet;
    }

    public LocalDateTime getVeg() {
        return veg;
    }

    public String getKezdemenyezo() {
        return kezdemenyezo;
    }

    public String getFogado() {
        return fogado;
    }

    Duration getBeszelgetesHossz() {
        return Duration.between(kezdet, veg);
    }

    Beszelgetes(String sor) {
        String[] darabolt = sor.split(";");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy.MM.dd-HH:mm:ss");
        kezdet = LocalDateTime.parse(darabolt[0], formatter);
        veg = LocalDateTime.parse(darabolt[1], formatter);
        kezdemenyezo = darabolt[2];
        fogado = darabolt[3];
    }
}

public class CsevegesGUI extends Application {
    @Override
    public void start(Stage stage) {
        // 9. feladat a.)
        Text kezdemenyezoFelirat = new Text("Kezdeményező");
        ComboBox<String> kezdemenyezoValaszto = new ComboBox<>();
        Text fogadoFelirat = new Text("Fogadó (partner)");
        ComboBox<String> fogadoValaszto = new ComboBox<>();
        Text csevegesekFelirat = new Text("Csevegések");
        TextArea csevegesekTextArea = new TextArea("");

        GridPane gridPane = new GridPane();
        gridPane.add(kezdemenyezoFelirat, 0, 0);
        gridPane.add(kezdemenyezoValaszto, 1, 0);
        gridPane.add(fogadoFelirat, 0, 1);
        gridPane.add(fogadoValaszto, 1, 1);
        gridPane.add(csevegesekFelirat, 0, 2);
        gridPane.add(csevegesekTextArea, 0, 3, 2, 1);
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(gridPane, 400, 375);
        kezdemenyezoValaszto.setMaxWidth(200);
        fogadoValaszto.setMaxWidth(200);
        stage.setTitle("Csevegés GUI");
        stage.setScene(scene);
        stage.show();

        // 9. feladat b.)
        List<Beszelgetes> beszelgetesList = new ArrayList<>();
        File inputFile = new File("csevegesek.txt");
        try (Scanner scanner = new Scanner(inputFile)) {
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String aktualisSor = scanner.nextLine();
                beszelgetesList.add(new Beszelgetes(aktualisSor));
            }
        } catch (FileNotFoundException exception) {
            System.err.print("Fájl nem található!");
            return;
        }
        List<String> kezdemenyezoList = new ArrayList<>();
        List<String> fogadoList = new ArrayList<>();
        for (Beszelgetes beszelgetes : beszelgetesList) {
            String kezdemenyezo = beszelgetes.getKezdemenyezo();
            if (!kezdemenyezoList.contains(kezdemenyezo)) {
                kezdemenyezoList.add(kezdemenyezo);
            }
            String fogado = beszelgetes.getFogado();
            if (!fogadoList.contains(fogado)) {
                fogadoList.add(fogado);
            }
        }
        java.util.Collections.sort(kezdemenyezoList);
        java.util.Collections.sort(fogadoList);
        kezdemenyezoValaszto.getItems().addAll(kezdemenyezoList);
        fogadoValaszto.getItems().addAll(fogadoList);
        kezdemenyezoValaszto.setValue(kezdemenyezoList.get(0));
        fogadoValaszto.setValue(fogadoList.get(fogadoList.size() - 1));

        // 9. feladat c.)
        csevegesekKivalogatasa(kezdemenyezoValaszto, fogadoValaszto, csevegesekTextArea, beszelgetesList);

        kezdemenyezoValaszto.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                csevegesekKivalogatasa(kezdemenyezoValaszto, fogadoValaszto, csevegesekTextArea, beszelgetesList);
            }
        });
        fogadoValaszto.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                csevegesekKivalogatasa(kezdemenyezoValaszto, fogadoValaszto, csevegesekTextArea, beszelgetesList);
            }
        });
    }

    private void csevegesekKivalogatasa(ComboBox<String> kezdemenyezoValaszto, ComboBox<String> fogadoValaszto, TextArea csevegesekTextArea, List<Beszelgetes> beszelgetesList) {
        String kezdemenyezo = kezdemenyezoValaszto.getValue();
        String fogado = fogadoValaszto.getValue();
        csevegesekTextArea.setText("");
        StringBuilder fieldContent = new StringBuilder("");
        DateTimeFormatter kiirasFormatter = DateTimeFormatter.ofPattern("yy.MM.dd-HH:mm:ss");
        int i = 0;
        for (Beszelgetes beszelgetes : beszelgetesList) {
            if (beszelgetes.getKezdemenyezo().equals(kezdemenyezo) && beszelgetes.getFogado().equals(fogado)) {
                String bejegyzes = i++ + ". " + beszelgetes.getKezdet().format(kiirasFormatter)
                        + " --> " + beszelgetes.getVeg().format(kiirasFormatter);
                fieldContent.append(bejegyzes);
                fieldContent.append('\n');
            }
        }
        if (fieldContent.toString().isEmpty()) {
            fieldContent.append("Nem történt beszélgetés.");
        }
        csevegesekTextArea.setText(fieldContent.toString());
    }
}
