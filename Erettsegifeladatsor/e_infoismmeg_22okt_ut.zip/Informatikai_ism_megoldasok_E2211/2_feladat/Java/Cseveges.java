import java.io.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.*;

// 2. Feladat
class Beszelgetes {
    private LocalDateTime kezdet;
    private LocalDateTime veg;
    private String kezdemenyezo;
    private String fogado;

    public LocalDateTime getKezdet() {
        return kezdet;
    }

    public LocalDateTime getVeg() {
        return veg;
    }

    public String getKezdemenyezo() {
        return kezdemenyezo;
    }

    public String getFogado() {
        return fogado;
    }

    Duration getBeszelgetesHossz() {
        return Duration.between(kezdet, veg);
    }

    Beszelgetes(String sor) {
        String[] darabolt = sor.split(";");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy.MM.dd-HH:mm:ss");
        kezdet = LocalDateTime.parse(darabolt[0], formatter);
        veg = LocalDateTime.parse(darabolt[1], formatter);
        kezdemenyezo = darabolt[2];
        fogado = darabolt[3];
    }
}

public class Cseveges {
    public static void main(String[] args) {
        // 3. Feladat
        List<Beszelgetes> beszelgetesList = new ArrayList<>();
        File inputFile = new File("csevegesek.txt");
        try (Scanner scanner = new Scanner(inputFile)) {
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String aktualisSor = scanner.nextLine();
                beszelgetesList.add(new Beszelgetes(aktualisSor));
            }
        } catch (FileNotFoundException exception) {
            System.err.print("Fájl nem található!");
            return;
        }
        List<String> tagList = new ArrayList<>();
        File inputFile2 = new File("tagok.txt");
        try (Scanner scanner = new Scanner(inputFile2)) {
            while (scanner.hasNextLine()) {
                tagList.add(scanner.nextLine());
            }
        } catch (FileNotFoundException exception) {
            System.err.print("Fájl nem található!");
            return;
        }

        // 4. Feladat
        System.out.println("4. feladat: Tagok száma: " + tagList.size() + "fő - Beszélgetések: "
                + beszelgetesList.size() + "db");

        // 5. Feladat
        Beszelgetes maxBeszelgetes = beszelgetesList.get(0);
        for (Beszelgetes beszelgetes : beszelgetesList) {
            if (beszelgetes.getBeszelgetesHossz().compareTo(maxBeszelgetes.getBeszelgetesHossz()) > 0) {
                maxBeszelgetes = beszelgetes;
            }
        }
        System.out.println("5. feladat: Leghosszabb beszélgetés adatai");
        System.out.println("        Kezdeményező: " + maxBeszelgetes.getKezdemenyezo());
        System.out.println("        Fogadó:       " + maxBeszelgetes.getFogado());
        DateTimeFormatter kiirasFormatter = DateTimeFormatter.ofPattern("yy.MM.dd-HH:mm:ss");
        System.out.println("        Kezdete:      " + maxBeszelgetes.getKezdet().format(kiirasFormatter));
        System.out.println("        Vége:         " + maxBeszelgetes.getVeg().format(kiirasFormatter));
        System.out.println("        Hossz:        " + maxBeszelgetes.getBeszelgetesHossz().getSeconds() + "mp");

        // 6. Feladat
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String nev;
        try {
            System.out.print("6. feladat: Adja meg egy tag nevét: ");
            nev = reader.readLine();
        } catch (IOException e) {
            System.err.print("Hiba történt a beolvasáskor!");
            return;
        }
        Duration eddigiIdo = Duration.ZERO;
        for (Beszelgetes beszelgetes : beszelgetesList) {
            if (beszelgetes.getKezdemenyezo().equals(nev) || beszelgetes.getFogado().equals(nev)) {
                eddigiIdo = eddigiIdo.plus(beszelgetes.getBeszelgetesHossz());
            }
        }
        if (eddigiIdo.isZero()) {
            System.out.println("        A beszélgetések összes ideje: 00:00:00");
        } else {
            long masodpercek = eddigiIdo.getSeconds();
            String idoFormazva = String.format("%02d:%02d:%02d", masodpercek / 3600, (masodpercek % 3600) / 60, (masodpercek % 60));
            System.out.println("        A beszélgetések összes ideje: " + idoFormazva);
        }

        // 7. Feladat
        HashMap<String, Integer> emberekBeszelgetesei = new HashMap<>();
        for (String ember : tagList) {
            emberekBeszelgetesei.put(ember, 0);
        }
        for (Beszelgetes beszelgetes : beszelgetesList) {
            String kulcs1 = beszelgetes.getKezdemenyezo();
            Integer szereplesekSzama1 = emberekBeszelgetesei.get(kulcs1);
            emberekBeszelgetesei.put(kulcs1, szereplesekSzama1 + 1);

            String kulcs2 = beszelgetes.getFogado();
            Integer szereplesekSzama2 = emberekBeszelgetesei.get(kulcs2);
            emberekBeszelgetesei.put(kulcs2, szereplesekSzama2 + 1);
        }
        System.out.println("7. feladat: Nem beszélgettek senkivel");
        for (Map.Entry<String, Integer> bejegyzes : emberekBeszelgetesei.entrySet()) {
            if (bejegyzes.getValue() == 0) {
                System.out.println("        " + bejegyzes.getKey());
            }
        }

        // 8. Feladat
        LocalDateTime maxCsendKezdete = LocalDateTime.of(2021, Month.SEPTEMBER, 27, 15, 0, 0);
        LocalDateTime maxCsendVege = beszelgetesList.get(0).getKezdet();
        Duration maxCsendHossz = Duration.between(maxCsendVege, maxCsendKezdete).abs();
        LocalDateTime kurzor = beszelgetesList.get(0).getVeg();

        for (Beszelgetes beszelgetes : beszelgetesList) {
            if (beszelgetes.getKezdet().isAfter(kurzor)) {
                Duration eddigTartottACsend = Duration.between(beszelgetes.getKezdet(), kurzor).abs();
                if (eddigTartottACsend.compareTo(maxCsendHossz) > 0) {
                    maxCsendHossz = eddigTartottACsend;
                    maxCsendKezdete = kurzor;
                    maxCsendVege = beszelgetes.getKezdet();
                }
            }
            if (beszelgetes.getVeg().compareTo(kurzor) > 0) {
                kurzor = beszelgetes.getVeg();
            }
        }
        System.out.println("8. feladat: Leghosszabb csendes időszak 15h-tól");
        System.out.println("        Kezdete:      " + maxCsendKezdete.format(kiirasFormatter));
        System.out.println("        Vége:         " + maxCsendVege.format(kiirasFormatter));
        long maxCsendMasodpercekben = maxCsendHossz.getSeconds();
        String maxCsendhosszFormazva = String.format("%02d:%02d:%02d", maxCsendMasodpercekben / 3600, (maxCsendMasodpercekben % 3600) / 60, (maxCsendMasodpercekben % 60));
        System.out.println("        Hossza:       " + maxCsendhosszFormazva);
    }
}
