-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!
-- 13. feladat
CREATE DATABASE mozi
    CHARACTER SET utf8
    COLLATE utf8_hungarian_ci;
-- ***
-- 15. feladat
SELECT COUNT(id) as "vetitesek_szama"
FROM vetites
WHERE kezdes = '20:00';
-- ***
-- 16. feladat
SELECT COUNT(jegy.id) as "jegy_db", vendeg.nev as "vendeg_nev"
FROM jegy
         INNER JOIN vendeg on jegy.vendegId = vendeg.id
GROUP BY (jegy.vendegId)
ORDER BY jegy_db DESC
LIMIT 5;
-- ***
-- 17. feladat
UPDATE film
SET cim = 'Csillagok között'
WHERE cim = 'Interstellar';
-- ***
-- 18. feladat
INSERT INTO filmtipus (nev)
VALUES ('Animációs');
-- ***
-- 19. feladat
SELECT nev as "nev", count(jegy.id) as 'teljes_aru_jegy_db'
FROM vendeg
         INNER JOIN jegy on vendeg.id = jegy.vendegId
WHERE nev = 'Fodor András'
  and kedvezmeny = 0;
-- ***
-- 20. feladat
SELECT film.cim as "film_neve",
       COUNT(jegy.id) as 'jegy_darabszam',
       SUM(film.jegyar - film.jegyar * jegy.kedvezmeny / 100) as 'teljes_bevetel'
FROM film
         INNER JOIN vetites on film.id = vetites.filmId
         INNER JOIN jegy on vetites.id = jegy.vetitesId
GROUP BY film.cim
ORDER BY teljes_bevetel DESC
LIMIT 1;
-- ***
